package com.athkarmuslim.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

private val Navy = Color(0xFF101A35)
private val Navy2 = Color(0xFF1B294B)
private val Gold = Color(0xFFD6B56D)
private val Cream = Color(0xFFF7F3E9)

data class Dhikr(
    val id: Long, val category: String, val text: String, val count: Int,
    val note: String = "", val favorite: Boolean = false, val progress: Int = 0
)

class MainActivity : ComponentActivity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var azimuth by mutableFloatStateOf(0f)
    private var qiblaBearing by mutableFloatStateOf(0f)
    private var locationText by mutableStateOf("لم يتم تحديد الموقع")
    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { updateLocation() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.also {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        createNotificationChannel()
        updateLocation()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Gold, secondary = Gold, background = Navy, surface = Navy2,
                onPrimary = Navy, onBackground = Cream, onSurface = Cream
            )) {
                AthkarApp(
                    onReminder = { scheduleReminder() },
                    onQibla = { requestLocationPermission() },
                    bearing = qiblaBearing,
                    heading = azimuth,
                    location = locationText
                )
            }
        }
    }

    private fun requestLocationPermission() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED) {
            requestPermissions.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        } else updateLocation()
    }

    private fun updateLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val loc: Location? = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (loc != null) {
                qiblaBearing = bearingToKaaba(loc.latitude, loc.longitude)
                locationText = "تم تحديد الموقع"
            } else locationText = "فعّل الموقع للحصول على اتجاه القبلة"
        } catch (_: Exception) { locationText = "تعذر تحديد الموقع" }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            val matrix = FloatArray(9); val orientation = FloatArray(3)
            SensorManager.getRotationMatrixFromVector(matrix, event.values)
            SensorManager.getOrientation(matrix, orientation)
            azimuth = Math.toDegrees(orientation[0].toDouble()).toFloat()
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onPause() { super.onPause(); sensorManager.unregisterListener(this) }
    override fun onResume() { super.onResume(); sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.also { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) } }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("athkar_daily", "تذكير الأذكار", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun scheduleReminder() {
        val intent = Intent(this, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(this, 10, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 7); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
    }
    private fun bearingToKaaba(lat: Double, lon: Double): Float {
        val lat1 = Math.toRadians(lat); val lat2 = Math.toRadians(21.4225)
        val dLon = Math.toRadians(39.8262 - lon)
        val y = sin(dLon); val x = cos(lat1) * tan(lat2) - sin(lat1) * cos(dLon)
        return ((Math.toDegrees(atan2(y, x)) + 360) % 360).toFloat()
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val notification = Notification.Builder(context, "athkar_daily")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("أذكار مسلم")
            .setContentText("لا تنسَ أذكارك، ابدأ يومك بذكر الله")
            .setAutoCancel(true).build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(101, notification)
    }
}

@Composable
private fun AthkarApp(onReminder: () -> Unit, onQibla: () -> Unit, bearing: Float, heading: Float, location: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var data by remember { mutableStateOf(loadDhikr(context)) }
    var tab by remember { mutableStateOf("الرئيسية") }
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Dhikr?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Dhikr?>(null) }

    fun save() = saveDhikr(context, data)
    Scaffold(
        containerColor = Navy,
        topBar = {
            Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 16.dp)) {
                Text("أَذْكَارُ مُسْلِم", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("طمأنينة القلب بذكر الله", color = Cream.copy(alpha = .72f), fontSize = 12.sp)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Navy2, contentColor = Gold) {
                listOf("الرئيسية", "الأذكار", "التسبيح", "القبلة", "المزيد").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item },
                        icon = { Icon(when(item) { "الرئيسية" -> Icons.Default.Home; "الأذكار" -> Icons.Default.MenuBook; "التسبيح" -> Icons.Default.TouchApp; "القبلة" -> Icons.Default.Explore; else -> Icons.Default.Settings }, null) },
                        label = { Text(item, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Navy))
                }
            }
        },
        floatingActionButton = {
            if (tab == "الأذكار") FloatingActionButton(onClick = { editing = null; showEditor = true }, containerColor = Gold, contentColor = Navy) { Icon(Icons.Default.Add, "إضافة ذكر") }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp)) {
            when(tab) {
                "الرئيسية" -> {
                    Spacer(Modifier.height(10.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = Navy2), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("السلام عليكم ورحمة الله", color = Cream, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("اجعل لسانك رطباً بذكر الله", color = Gold)
                            Spacer(Modifier.height(16.dp))
                            Text("﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾", color = Cream, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("ابدأ بالأذكار", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    listOf("أذكار الصباح", "أذكار المساء", "أذكار الصلاة", "أذكار النوم").forEach { cat ->
                        CategoryCard(cat, data.count { it.category == cat }) { tab = "الأذكار"; query = ""; selected = null }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("مواقيت الصلاة", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    PrayerTimesCard()
                }
                "الأذكار" -> {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("ابحث عن ذكر...") }, singleLine = true)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("كل الأذكار (${data.size})", color = Gold, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { data = data.map { it.copy(favorite = !it.favorite) }; save() }) { Text("تبديل المفضلة") }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(data.filter { it.text.contains(query, true) || it.category.contains(query, true) }) { d ->
                            DhikrCard(d, onClick = { selected = d }, onFav = { data = data.map { if(it.id==d.id) it.copy(favorite=!it.favorite) else it }; save() })
                        }
                    }
                }
                "التسبيح" -> TasbeehScreen()
                "القبلة" -> QiblaScreen(bearing, heading, location, onQibla)
                else -> {
                    Spacer(Modifier.height(12.dp))
                    Text("الإعدادات والخدمات", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    MenuCard("تفعيل تذكير يومي بالأذكار", "سيصلك تنبيه يومياً الساعة 7 صباحاً") { onReminder() }
                    MenuCard("حول التطبيق", "أذكار مسلم – يعمل دون اتصال بالإنترنت") {}
                }
            }
        }
    }
    if (selected != null) {
        val d = selected!!
        AlertDialog(onDismissRequest = { selected = null }, containerColor = Navy2,
            title = { Text(d.category, color = Gold) },
            text = { Column {
                Text(d.text, color = Cream, fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))
                Text("التكرار: ${d.progress} / ${d.count}", color = Gold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { data = data.map { if(it.id==d.id) it.copy(progress=(it.progress+1).coerceAtMost(it.count)) else it }; save(); selected = data.first { it.id==d.id } }) { Text("تسبيح +1") }
                    TextButton(onClick = { data = data.map { if(it.id==d.id) it.copy(progress=0) else it }; save(); selected = data.first { it.id==d.id } }) { Text("إعادة") }
                }
            } },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("إغلاق") } },
            dismissButton = { TextButton(onClick = { editing = d; showEditor = true; selected = null }) { Text("تعديل") } }
        )
    }
    if (showEditor) {
        DhikrEditor(editing, onDismiss = { showEditor = false }, onSave = { item ->
            data = if (editing == null) data + item else data.map { if(it.id == item.id) item else it }
            save(); showEditor = false
        }, onDelete = { item -> data = data.filterNot { it.id == item.id }; save(); showEditor = false })
    }
}

@Composable private fun CategoryCard(title: String, count: Int, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Navy2), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, null, tint = Gold)
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = Cream, fontWeight = FontWeight.SemiBold); Text("$count ذكر", color = Cream.copy(.6f), fontSize = 12.sp) }
            Icon(Icons.Default.ChevronLeft, null, tint = Gold)
        }
    }
}
@Composable private fun DhikrCard(d: Dhikr, onClick: () -> Unit, onFav: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Navy2), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d.category, color = Gold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = onFav) { Icon(if(d.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Gold) }
            }
            Text(d.text, color = Cream, fontSize = 17.sp, lineHeight = 29.sp, maxLines = 4)
            Text("التكرار ${d.progress}/${d.count}", color = Gold.copy(.8f), fontSize = 11.sp)
        }
    }
}
@Composable private fun TasbeehScreen() {
    var count by remember { mutableIntStateOf(0) }
    var phrase by remember { mutableStateOf("سبحان الله") }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("عداد التسبيح", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        var expanded by remember { mutableStateOf(false) }
        Box {
            OutlinedButton(onClick = { expanded = true }) { Text(phrase, color = Cream) }
            DropdownMenu(expanded, { expanded = false }) {
                listOf("سبحان الله", "الحمد لله", "الله أكبر", "أستغفر الله", "لا إله إلا الله").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { phrase = it; expanded = false }) }
            }
        }
        Spacer(Modifier.height(28.dp))
        Box(Modifier.size(210.dp).background(Gold, CircleShape).clickable { count++ }, contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$count", color = Navy, fontSize = 52.sp, fontWeight = FontWeight.Bold)
                Text("اضغط للتسبيح", color = Navy)
            }
        }
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = { count = 0 }) { Text("تصفير العداد", color = Cream) }
    }
}
@Composable private fun QiblaScreen(bearing: Float, heading: Float, location: String, onLocate: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("اتجاه القبلة", color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp)); Text(location, color = Cream.copy(.7f))
        Spacer(Modifier.height(30.dp))
        Box(Modifier.size(250.dp).background(Navy2, CircleShape), contentAlignment = Alignment.Center) {
            Text("🕋", fontSize = 46.sp, modifier = Modifier.offset(y = (-76).dp))
            Text("N", color = Gold, modifier = Modifier.offset(y = (-112).dp))
            Icon(Icons.Default.Navigation, null, tint = Gold, modifier = Modifier.size(70.dp).offset(y = 20.dp).then(Modifier))
            Text("${bearing.roundToInt()}°", color = Cream, modifier = Modifier.offset(y = 80.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("اتجاه القبلة من الشمال: ${bearing.roundToInt()}°", color = Cream)
        Text("حرّك الهاتف لمعايرة البوصلة: ${heading.roundToInt()}°", color = Cream.copy(.65f), fontSize = 12.sp)
        Spacer(Modifier.height(12.dp)); Button(onClick = onLocate) { Text("تحديد موقعي") }
        Text("أبعد الهاتف عن المعادن والأجهزة المغناطيسية", color = Cream.copy(.55f), fontSize = 11.sp)
    }
}
@Composable private fun PrayerTimesCard() {
    val now = Calendar.getInstance()
    val times = remember { calculatePrayerTimes(now.get(Calendar.DAY_OF_YEAR), 15.37, 44.19, 3.0) }
    Column(Modifier.fillMaxWidth().background(Navy2, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(SimpleDateFormat("EEEE، d MMMM", Locale("ar")).format(Date()), color = Cream.copy(.7f), fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        times.forEach { (name, time) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(name, color = Cream); Text(time, color = Gold, fontWeight = FontWeight.Bold)
            }
        }
        Text("أوقات تقريبية لصنعاء – عدّل الموقع وطريقة الحساب في إصدار لاحق", color = Cream.copy(.45f), fontSize = 10.sp)
    }
}
@Composable private fun MenuCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Navy2)) {
        Column(Modifier.padding(16.dp)) { Text(title, color = Cream); Text(subtitle, color = Cream.copy(.6f), fontSize = 12.sp) }
    }
}
@Composable private fun DhikrEditor(existing: Dhikr?, onDismiss: () -> Unit, onSave: (Dhikr) -> Unit, onDelete: (Dhikr) -> Unit) {
    var category by remember { mutableStateOf(existing?.category ?: "أذكار الصباح") }
    var text by remember { mutableStateOf(existing?.text ?: "") }
    var count by remember { mutableStateOf((existing?.count ?: 3).toString()) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = Navy2,
        title = { Text(if(existing == null) "إضافة ذكر جديد" else "تعديل الذكر", color = Gold) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            var expanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { expanded = true }) { Text(category, color = Cream) }
                DropdownMenu(expanded, { expanded = false }) {
                    listOf("أذكار الصباح", "أذكار المساء", "أذكار الصلاة", "أذكار النوم", "أذكار عامة").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { category = it; expanded = false }) }
                }
            }
            OutlinedTextField(text, { text = it }, label = { Text("نص الذكر") }, minLines = 3)
            OutlinedTextField(count, { count = it.filter(Char::isDigit) }, label = { Text("عدد التكرار") }, singleLine = true)
        } },
        confirmButton = { TextButton(onClick = { if(text.isNotBlank() && (count.toIntOrNull() ?: 0) > 0) onSave(Dhikr(existing?.id ?: System.currentTimeMillis(), category, text.trim(), count.toInt(), existing?.note ?: "", existing?.favorite ?: false, existing?.progress ?: 0)) }) { Text("حفظ") } },
        dismissButton = { Row {
            if(existing != null) TextButton(onClick = { onDelete(existing) }) { Text("حذف", color = Color.Red) }
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        } }
    )
}

private fun loadDhikr(context: Context): List<Dhikr> {
    val prefs = context.getSharedPreferences("athkar_data", Context.MODE_PRIVATE)
    val raw = prefs.getString("items", null)
    if (raw != null) return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i -> arr.getJSONObject(i).let { o ->
            Dhikr(o.getLong("id"), o.getString("category"), o.getString("text"), o.getInt("count"),
                o.optString("note"), o.optBoolean("favorite"), o.optInt("progress"))
        } }
    } catch (_: Exception) { defaultDhikr() }
    return defaultDhikr().also { saveDhikr(context, it) }
}
private fun saveDhikr(context: Context, items: List<Dhikr>) {
    val arr = JSONArray()
    items.forEach { d -> arr.put(JSONObject().put("id",d.id).put("category",d.category).put("text",d.text).put("count",d.count).put("note",d.note).put("favorite",d.favorite).put("progress",d.progress)) }
    context.getSharedPreferences("athkar_data", Context.MODE_PRIVATE).edit().putString("items", arr.toString()).apply()
}
private fun defaultDhikr() = listOf(
    Dhikr(1,"أذكار الصباح","أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",1),
    Dhikr(2,"أذكار الصباح","اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ",1),
    Dhikr(3,"أذكار المساء","أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",1),
    Dhikr(4,"أذكار الصلاة","أَسْتَغْفِرُ اللَّهَ (ثلاثاً)، اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ",3),
    Dhikr(5,"أذكار النوم","بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",1),
    Dhikr(6,"أذكار عامة","سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",100),
    Dhikr(7,"أذكار عامة","أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",100)
)
private fun calculatePrayerTimes(day: Int, latitude: Double, longitude: Double, timezone: Double): List<Pair<String,String>> {
    val decl = 0.409 * sin(2 * PI * day / 365.0 - 1.39)
    val solarNoon = 12.0 + timezone - longitude / 15.0
    fun hourAngle(angle: Double): Double {
        val lat = Math.toRadians(latitude)
        val cosH = (sin(Math.toRadians(angle)) - sin(lat)*sin(decl)) / (cos(lat)*cos(decl))
        return Math.toDegrees(acos(cosH.coerceIn(-1.0,1.0))) / 15.0
    }
    fun fmt(v: Double): String {
        val mins = ((v * 60).roundToInt() % (24*60) + 24*60) % (24*60)
        return "%02d:%02d".format(Locale.US, mins/60, mins%60)
    }
    val sunrise = solarNoon - hourAngle(-0.833)
    val sunset = solarNoon + hourAngle(-0.833)
    val fajr = solarNoon - hourAngle(-18.0)
    val isha = solarNoon + hourAngle(-17.0)
    val asrAngle = Math.toDegrees(atan(1.0 + tan(abs(Math.toRadians(latitude)-decl))))
    val asr = solarNoon + hourAngle(90.0-asrAngle)
    return listOf("الفجر" to fmt(fajr), "الشروق" to fmt(sunrise), "الظهر" to fmt(solarNoon), "العصر" to fmt(asr), "المغرب" to fmt(sunset), "العشاء" to fmt(isha))
}
